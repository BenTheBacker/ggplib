cgreenlet from https://github.com/geertj/cgreenlet

small cosmetic modifcations by Richard Emslie to compile in this environment.  LICENSE/AUTHORS
intact.
