#define CATCH_CONFIG_MAIN
#include <catch.hpp>
#include <fmt/format.cc>
#include <fmt/printf.cc>
#include <fmt/ostream.cc>
