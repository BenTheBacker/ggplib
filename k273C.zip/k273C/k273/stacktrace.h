#pragma once

// std includes
#include <string>

namespace K273 {
    std::string getStackTrace();
}
